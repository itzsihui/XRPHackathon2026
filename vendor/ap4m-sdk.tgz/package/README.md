# AP4M SDK (hackathon package)

This is the AP4M SDK package served by the hackathon service. The kit files `ap4m-x402.mjs` and
`verify-receipt.mjs` build on it; you normally use those, and `ap4m-hackathon-sdk.cjs` (or `.js`), rather than
calling this package directly.

Install it from the hackathon service, not from the public npm registry:

```bash
npm install ethers@6.17.0 <service URL>/sdk/ap4m-sdk.tgz
```

Start with `<service URL>/llms.txt`. It lists the network, the contract addresses, the guides (quickstart, x402,
receipts, API reference, troubleshooting) and every kit file, and links `AGENTS.md` for AI coding tools.
